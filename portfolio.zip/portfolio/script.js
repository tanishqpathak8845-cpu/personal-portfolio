// =====================================
// TANISHQ PATHAK - PORTFOLIO JAVASCRIPT
// =====================================


// 1. MOBILE NAVIGATION

const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
const navItems = document.querySelectorAll(".nav-link");

menuToggle.addEventListener("click", function () {

    const isOpen = navLinks.classList.toggle("open");

    menuToggle.classList.toggle("open", isOpen);

    menuToggle.setAttribute("aria-expanded", isOpen);

});


function closeMenu() {

    navLinks.classList.remove("open");
    menuToggle.classList.remove("open");

    menuToggle.setAttribute("aria-expanded", "false");

}


navItems.forEach(function (link) {

    link.addEventListener("click", function () {

        closeMenu();

    });

});


document.addEventListener("click", function (event) {

    const clickedInsideNavbar =
        event.target.closest(".navbar");

    if (!clickedInsideNavbar) {
        closeMenu();
    }

});


// 2. SCROLL REVEAL ANIMATION

const revealElements = document.querySelectorAll(".reveal");

const prefersReducedMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)"
).matches;


if ("IntersectionObserver" in window && !prefersReducedMotion) {

    const revealObserver = new IntersectionObserver(
        function (entries, observer) {

            entries.forEach(function (entry) {

                if (entry.isIntersecting) {

                    entry.target.classList.add("visible");

                    observer.unobserve(entry.target);

                }

            });

        },
        {
            threshold: 0.12
        }
    );


    revealElements.forEach(function (element) {

        revealObserver.observe(element);

    });

} else {

    revealElements.forEach(function (element) {

        element.classList.add("visible");

    });

}


// 3. ACTIVE NAVIGATION LINK

const sections = document.querySelectorAll(
    "main section[id]"
);


if ("IntersectionObserver" in window) {

    const sectionObserver = new IntersectionObserver(
        function (entries) {

            entries.forEach(function (entry) {

                if (entry.isIntersecting) {

                    const currentId = entry.target.id;

                    navItems.forEach(function (link) {

                        const isActive =
                            link.getAttribute("href") === "#" + currentId;

                        link.classList.toggle("active", isActive);

                    });

                }

            });

        },
        {
            rootMargin: "-25% 0px -60% 0px"
        }
    );


    sections.forEach(function (section) {

        sectionObserver.observe(section);

    });

}


// 4. AUTOMATIC FOOTER YEAR

const currentYear = document.getElementById("currentYear");

currentYear.textContent = "© " + new Date().getFullYear();


// 5. PREVENT ANCHOR FLASH ON INITIAL PAGE LOAD

window.addEventListener("load", function () {

    document.body.classList.add("page-loaded");

});


// 6. CONSOLE MESSAGE

console.log(
    "%cWelcome to Tanishq Pathak's Portfolio!",
    "color: #a78bfa; font-size: 16px; font-weight: bold;"
);

console.log(
    "%cCode. Create. Repeat.",
    "color: #60a5fa; font-size: 12px;"
);